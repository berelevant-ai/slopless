#!/usr/bin/env python3
# Extracts info from Elsevier XML
# @since   24-APR-2021
# @version 01-JUN-2021

import os, xml.etree.ElementTree as et
import GptDetectorLocal

detectorBase = GptDetectorLocal.GptDetectorLocal('roberta-base-openai-detector')

def extractMetadata(xml):
    ns = {'ce': 'http://www.elsevier.com/xml/common/dtd', 'dc': 'http://purl.org/dc/elements/1.1/', 'sa': 'http://www.elsevier.com/xml/common/struct-aff/dtd',
          'xocs': 'http://www.elsevier.com/xml/xocs/dtd', 'default': 'http://www.elsevier.com/xml/svapi/article/dtd'}

    def extractDate(root, xpath):
        try:
            date = root.find(xpath, ns)
            return date.attrib['year']+"-"+date.attrib['month']+"-"+date.attrib['day']
        except:
            return 'N/A'

    def get(root, xpath):
        try:    return root.find(xpath, ns).text
        except: return 'N/A'

    root = et.fromstring(xml)
    si  = get(root, './/xocs:hub-sec-title')
    pii = get(root, './/xocs:pii-unformatted')
    doi = get(root, './/ce:doi')
    vol = get(root, './/xocs:vol-first')
    typ = get(root, './/default:pubType')
    abs = get(root, './/dc:description')

    vol = int(vol) if vol != 'N/A' else 0
    abs = abs.strip().replace('\n',' ').replace('\t', ' ') if abs else ''

    dateReceived = extractDate(root, './/ce:date-received')
    dateRevised  = extractDate(root, './/ce:date-revised')
    dateAccepted = extractDate(root, './/ce:date-accepted')

    countries = set([country.text for country in root.findall('.//sa:country', ns)])

    scoreRoberta = detectorBase.detect(abs)

    # Full text articles in volumes 56-83
    if typ == 'fla' and vol in range(56, 83 + 1):
        print(f"{pii}\t{doi}\t{typ}\t{vol}\t{si}\t{', '.join(countries)}\t{dateReceived}\t{dateRevised}\t{dateAccepted}\t{abs}\t{scoreRoberta}")

# Entry point
if __name__ == '__main__':
    dir = 'xml/'
    for ficname in sorted(os.listdir(dir)):
        with open(dir+ficname) as f:
            extractMetadata(f.read())