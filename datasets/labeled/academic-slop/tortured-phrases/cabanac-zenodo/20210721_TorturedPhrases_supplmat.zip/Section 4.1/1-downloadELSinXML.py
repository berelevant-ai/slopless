#!/usr/bin/env python3
# Download XMLs from Elsevier with an API key (see http://dev.elsevier.com)
# @since   24-APR-2021
# @version 31-MAY-2021 Volumes 56-83

from crossref.restful import Journals, Etiquette
from os import path
import requests

# Guillaume's Elsevier API Key
apiKey = open('ELS-apiKey.txt').read().strip()

def screenJournal(issn):
    """ Queries the Crossref API for all DOIs created from 2016 with https://api.crossref.org/journals/0141-9331/works?filter=from-created-date:2016&order=desc&select=DOI,created,title&sort=created"""
    cr = Journals(etiquette=Etiquette('Paper Screener', '1.0', 'https://www.irit.fr/~Guillaume.Cabanac', 'guillaume.cabanac@univ-tlse3.fr'))
    
    # Note: Crossref shows a volume attribute but we cannot use it as filter in the query.
    # We ask for 2016- papers and will filter this result to keep volumes 56-83 (Feb ‘18 - June ‘21)
    for art in cr.works(issn).filter(from_created_date='2016').select('DOI,alternative-id').sort('created').order('desc'):
        artNo = art['alternative-id'][0]

        # Download XML if not already in xml/
        dstName = f'xml/{artNo}.xml'
        if not path.exists(dstName):
            # Asking Elsevier for full-test
            resp = requests.get(f"https://api.elsevier.com/content/article/doi/{art['DOI']}", params={"apiKey": apiKey, "httpAccept": "text/xml", "view": "FULL"})
            resp.raise_for_status
            with open(dstName, 'w') as f:
                f.write(resp.text)
            print(f'Wrote {artNo}')
        else:
            print(f'Skipping {artNo}: already present in xml/')


# Entry point
if __name__ == '__main__':
    screenJournal('0141-9331') # Microprocessors and Microsystems (1317)
#    screenJournal('1369-7021') # Materials Today (959)
#    screenJournal('0306-4573') # IP&M (631)
#    screenJournal('1751-1577') # Journal of Informetrics (312)