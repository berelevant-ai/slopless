#!/usr/bin/env python3
# GPT-2 detector
# Code adapted from https://github.com/openai/gpt-2-output-dataset/blob/master/detector/server.py
# @since   24-APR-2021
# @version 06-MAY-2021

from transformers import RobertaForSequenceClassification, RobertaTokenizer
import torch

class GptDetectorLocal:
    def __init__(self, model_name = 'roberta-large-openai-detector'):
        """ model_name 'roberta-base-openai-detector' or 'roberta-large-openai-detector' (https://huggingface.co/transformers/pretrained_models.html) """
        
        self.model_name = model_name
        self.device = "cuda" if torch.cuda.is_available() else "cpu"

        # Download models if not already present here ~/.cache/huggingface/transformers
        self.model = RobertaForSequenceClassification.from_pretrained(model_name)  
        self.tokenizer = RobertaTokenizer.from_pretrained(model_name)

    def detect(self, text: str):
        tokens = self.tokenizer.encode(text)
        all_tokens = len(tokens)
        tokens = tokens[:self.tokenizer.model_max_length - 2]  # model_max_length instead of max_len (deprecated in Transformers v4 https://newreleases.io/project/github/huggingface/transformers/release/v4.0.0)
        used_tokens = len(tokens)
        tokens = torch.tensor([self.tokenizer.bos_token_id] + tokens + [self.tokenizer.eos_token_id]).unsqueeze(0)
        mask = torch.ones_like(tokens)

        with torch.no_grad():
            logits = self.model(tokens.to(self.device), attention_mask=mask.to(self.device))[0]
            probs = logits.softmax(dim=-1)

        fake, real = probs.detach().cpu().flatten().numpy().tolist()
        return fake


# Entry point
if __name__ == '__main__':
    detectorBase = GptDetectorLocal('roberta-base-openai-detector')
    detectorLarge = GptDetectorLocal('roberta-large-openai-detector')

    print("base:" + str(detectorBase.detect('Long text')))
    print("large:" + str(detectorLarge.detect('Long text')))