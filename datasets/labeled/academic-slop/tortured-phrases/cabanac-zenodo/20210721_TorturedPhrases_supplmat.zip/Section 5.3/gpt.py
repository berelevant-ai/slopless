# prerequisite: GPT detector server running on localhost:8080
# (see https://github.com/openai/gpt-2-output-dataset/tree/master/detector for launch manual)
# usage:
# python3 gpt.py <infile>
# where infile is a 2-column TSV: "<abstract_id>\t<abstract>"
# output to stdout

import requests
import urllib.parse
import sys

with open(sys.argv[1]) as infile:
    for line in infile:
        sp = line.strip().split('\t')
        if not sp:
            continue
        url = 'http://localhost:8080/?' + urllib.parse.quote(sp[1])
        res = requests.get(url).json()
        print(sp[0] + '\t' + str(res['all_tokens']) + '\t' + str(res['fake_probability']))

