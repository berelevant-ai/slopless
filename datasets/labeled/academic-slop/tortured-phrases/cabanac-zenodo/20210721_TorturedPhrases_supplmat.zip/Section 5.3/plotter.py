import sys
import math
import matplotlib.pyplot as plt

def prepare(ax):
    ticks = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
    tick_labels = ['0.0', '0.1', '0.2', '0.3', '0.4', '0.5', '0.6', '0.7', '0.8', '0.9', '1.0']
    ax.set_xticks(ticks)
    ax.set_xticklabels(tick_labels)
    ax.set_xlabel('GPT detector score')
    ax.set_ylabel('Cumulative probability')

def emp_dist_impl(x, scores):
    cnt = 0
    for score in scores:
        if score < x:
            cnt += 1
    return cnt / len(scores)

def plot(ax, color, scores, delta):
    x_values = [0.01 * i for i in range(0, 101)]
    y_values = [emp_dist_impl(x, scores) for x in x_values]
    y_values_upper = [min(1.0, value + delta) for value in y_values]
    y_values_lower = [max(0.0, value - delta) for value in y_values]
    
    ax.plot(x_values, y_values, '-', color=color)
    ax.fill_between(x_values, y_values_lower, y_values_upper, alpha=0.2, color=color)

def read_scores(filename):
    res = []
    with open(filename, 'r') as infile:
        for line in infile:
            val_str = line.strip('\n')
            if val_str:
                res.append(float(val_str))
    return res

exp_in_filename = sys.argv[1]
control_in_filename = sys.argv[2]
out_filename = sys.argv[3]

scores_exp = read_scores(exp_in_filename)
delta_exp = math.sqrt(math.log(240.0) / (2 * len(scores_exp)))

scores_control = read_scores(control_in_filename)
delta_control = math.sqrt(math.log(240.0) / (2 * len(scores_control)))

fig,ax = plt.subplots()
prepare(ax)
plot(ax, 'tab:red', scores_exp, delta_exp)
plot(ax, 'tab:cyan', scores_control, delta_control)

plt.savefig(out_filename)
